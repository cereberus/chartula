package z_TEMP;

public class practice {
	
	public static int x = 2;
	
	
	  public static void encepence() {
		 if (x==2){System.out.println("Hahaa, mam Cię");}
		}

	 
	  public static void main(String[] args) {
		
		  
		encepence();
		
		System.out.println("not so quick");
		  	 	
		  	
		  	}
		}