package ZADANIA_03;

public class Zadanie_5__pi_karne {
	  public static void main(String[] args) {
	double pi=0;
	   	for (int i=1;i<10000;i=i+1)
	   		{


	pi = pi +(double)(1)/((double)(i)*(double)(i));
	
	
	  	 	}
	  	System.out.println(Math.sqrt(pi*6)+" to jest pi");
	  	}
	}
