package ZADANIA_05;

public class PytanieOdpowiedz {
    public String pytanie;
//    public String pytanie2;
    public String odpowiedz;
    
    public PytanieOdpowiedz(String pytanie, String pytanie2, String odpowiedz)
    {
   	 this.pytanie = pytanie;
   	 this.odpowiedz = odpowiedz;
//   	 this.pytanie2 = pytanie2;
    }
}
