package ZADANIA_02;

public class zadanie_2_gwiazdka_prim {

	public static void main(String[] args) {
		String s="";
	   	for (int i=0;i<10;i=i+1)
	   	{
	           for (int k=0;k<i;k=k+1)
	   		{
				s = s + i;
				System.out.println(s);
	           		
	   		}
	           
	   	}
	   	
	   }

}
