package ZADANIA_02;

public class zadanie_3 {

	  public static void main(String[] args) {
			String s="ala";
			 System.out.println(s);
			 
		   	for (int i=0;i<10;i=i+1)
		   	{
		           
					s = s + s;
					
		           	
		           System.out.println(s);
		   	}
		   	
		   }

}
