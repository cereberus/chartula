package ZADANIA_02;

public class zadanie_1 {

	   public static void main(String[] args) {
			String s= "";
			
			
		   	for (int i=0;i<10;i=i+1)
		   	{
		   		System.out.println(i);
		   		
				s = s+"a ";
		           	System.out.println(s);
		           	
		        s = s+ "b ";
		        	System.out.println(s);
		        	
		        s = s+ "c ";
		        	System.out.println(s);
		   	}
		   }
		}
   


