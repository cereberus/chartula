package ZADANIA_01;

public class zadanie_5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int c = 1;
		
		
		for (int i=1;c<100000;i=i+1)
	   	{
				c = c * i;
	           	System.out.println(i + " " + c);
	         
	   	}				
		
		System.out.println("Programowanie jest spoko!");
	}

}
