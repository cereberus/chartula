package trening_14_01_20;


public class cortex {
    
    public static void InitBrain(){
   	 System.out.println("zaczynam myslec...");
    }

public static int dodaj(int a, int b)
{

int funkcja_zwraca=a+b;
return(funkcja_zwraca);

}

//public static int ktoraWieks
//za(int a, int b)
//{
//
//int funkcja_zwraca;
//if (a>b) funkcja_zwraca=a;
//else funkcja_zwraca=b;
//
//return(funkcja_zwraca);
//
//}

}

