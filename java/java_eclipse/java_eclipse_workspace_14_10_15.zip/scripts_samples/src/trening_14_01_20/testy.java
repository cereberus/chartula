package trening_14_01_20;


public class testy {

    public static void main(String[] args) {
   	 // TODO Auto-generated method stub
   	 
   	cortex.InitBrain();

int liczba1=5;
int liczba2=7;

int wynik=cortex.dodaj(liczba1,liczba2);
//int wieksza=cortex.ktoraWieksza(liczba1,liczba2);
System.out.println(wynik);

    }

}