package arrays;

import java.util.Arrays;

public class array_to_string {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] tab = new int[5];
		tab[0]= 4;
		tab[1]= 2;
		tab[2]= 7;
		tab[3]= 6;
		tab[4]= 1;
		
	  	System.out.println("lista tab: "+ (Arrays.toString(tab)));
	}

}
