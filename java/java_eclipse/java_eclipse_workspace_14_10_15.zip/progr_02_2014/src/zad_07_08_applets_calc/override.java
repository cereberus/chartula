package zad_07_08_applets_calc;

public @interface override {

}
